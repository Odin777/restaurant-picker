import java.util.Scanner;

public class foodChooser
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        food foodObject = new food();

        System.out.print("Enter 1 to select a national theme, Enter 2 to randomly select: ");
        int selection = input.nextInt();

            if (selection == 1 || selection == 1)
                foodObject.chooseTheme();
            if (selection == 2 || selection == 2)
                foodObject.chooseRandom();
            if (selection != 1 && selection != 2)
                System.out.print("Incorrect input...");


        input.close();
    }
}
