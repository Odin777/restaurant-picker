public class fastFood extends food
{

}
