import java.util.Random;
import java.util.Scanner;

class food
{
    public String[][] themePlaces = {{"Americana", "Red Robin", "Boston Market", "Waxy O'Conners", "Mooya", "5 Guys Burgers", "Texas Road House", "Frankies", "Wendy's", "Tavern 42", "Johnny Rocket's", "Slider's Bar & Grill", "J Timmothies Tavern", "McBrides"},
                                     {"Asian", "Hana Japanese Steakhouse", "Asian Garden", "Sushi House", "Feng", "Seoul Korean BBQ", "Asian Bistro", "Sabaidee Thai"},
                                     {"Italian", "Spartan II", "New Haven Pizza Co.", "5 guys pizza", "Mona Lisa's", "Bin 300", "Manor Inn", "Fazoli's", "Zingarella's", "J&M Restaurant & Bar"},
                                     {"Indian/Middle Eastern", "Blue Moon", "Hasna's Afghan Fusion Cuisine", "Namaste India", "Himalaya Restaurant", "Bombay Olive"},
                                     {"Spanish", "Moe's Southwest Grill", "Plaza Azteca", "Mojo Nuevo Latino Cuisine", "El Sombrero's", "Latin Cravings", "Salsa's Southwest grill & bar", "El Pulpo Restaurant"}};

    public void chooseTheme()
    {
        Scanner input = new Scanner(System.in);                             // Scanner object creation
        Random rn = new Random(System.currentTimeMillis());                 // random object creation
        System.out.print("What kind of food do you want to consider?\n" +   // prompts
                themePlaces[0][0] + "<0>\n" +
                themePlaces[1][0] + "<1>\n" +
                themePlaces[2][0] + "<2>\n" +
                themePlaces[3][0] + "<3>\n" +
                themePlaces[4][0] + "<4>\n" +
                "Enter: ");
        int selection = input.nextInt();                                    // selection input
        if (selection > 4 || selection < 0)                                 // check range of input
        {
            System.out.println("Incorrect input");                          // exceeds == error
        }

        System.out.print(themePlaces[selection][rn.nextInt(themePlaces[selection].length) + 1]); // display random result within parameters
        input.close();

    }
    public void chooseRandom()
    {
        Random rn = new Random(System.currentTimeMillis());     // random object creation
        int rowIndex = rn.nextInt(4) + 0;                // create a random index within row limits
        System.out.print(themePlaces[rowIndex][rn.nextInt(themePlaces[rowIndex].length) + 1]);  // display random result
    }
}
