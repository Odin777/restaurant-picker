public class sitFood extends food
{

}
